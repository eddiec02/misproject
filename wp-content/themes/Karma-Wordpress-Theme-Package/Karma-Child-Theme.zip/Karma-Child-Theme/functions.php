<?php 

/* Insert custom functions here */

?>