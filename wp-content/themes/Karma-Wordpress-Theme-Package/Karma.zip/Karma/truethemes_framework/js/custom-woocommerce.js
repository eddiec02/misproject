/* ------------------------------------------------------------------------
Custom Scripts for WooCommerce Pages
* ------------------------------------------------------------------------- */
jQuery(document).ready(function(){
	
// Clean up forms
jQuery("p.form-row").find('br').remove();
  
});