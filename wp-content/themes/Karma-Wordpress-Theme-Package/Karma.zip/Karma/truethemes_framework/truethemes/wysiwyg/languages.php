<?php $strings = "tinyMCE.addI18n({en:{
karma_shortcodes:{desc : 'Add a Custom Shortcode'},}});";
?>